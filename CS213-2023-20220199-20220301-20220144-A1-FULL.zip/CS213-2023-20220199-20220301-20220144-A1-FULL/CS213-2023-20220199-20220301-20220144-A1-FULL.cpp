//Abdallah Ahmed Elsayed - 20220199 - bodanassarr5199@gmail.com
//Mohamed Amr - 20220301 - Moamr77991@gmail.com
//Ziad Ali - 20220144 - Ziad.ali2222777@gmail.com

#include <iostream>
#include <bits/stdc++.h>
#include "cmath"
#include "bmplib.cpp"

using namespace std;

unsigned char image1[SIZE][SIZE];
unsigned char image2[SIZE][SIZE];

void loadImage() {
    char imgName[103];
    // Get file name of grey scale of image1
    cout << "Enter image 1 file name: " << endl;
    string fileName;
    cin >> fileName;
    fileName = "../" + fileName;  // To read picture's path
    for (int i = 0; i < fileName.length(); ++i)imgName[i] = fileName[i];
    imgName[fileName.length()] = '\0';
    strcat(imgName, ".bmp");
    readGSBMP(imgName, image1);
}

void saveImage() {
    cout << "Do you want to apply this filter?" << endl << "Enter 1 for yes or 0 for no" << endl;
    int x;
    cin >> x;
    if (x == 1) {
        char imgName[100];
        // Get desired file name of grey scale of image1
        cout << "Enter the target image file name: " << endl;
        cin >> imgName;
        // Add .bmp extension and save image1
        strcat(imgName, ".bmp");
        writeGSBMP(imgName, image1);
    } else if (x == 0) cout << "Filter cancelled" << endl;
}

void darkenAndLightenFilter() {
    int y;
    cout << "if you want darker enter 1 ,lighter enter 2:" << endl;
    cin >> y;
    while (true) {
        if (y == 1) {
            for (int i = 0; i < SIZE; i++) {
                //make it darker
                for (int j = 0; j < SIZE; j++) {
                    image1[i][j] = image1[i][j] / 2;
                }
            }
            break;
        } else if (y == 2) {
            //make it brighter
            for (int i = 0; i < SIZE; i++) {
                for (int j = 0; j < SIZE; j++) {
                    image1[i][j] = (image1[i][j] + 255) / 2;
                }
            }
            break;
        } else {
            cout << "error" << endl;
            cout << "if you want darker enter 1 ,lighter enter 2:" << endl;
            cin >> y;
        }
    }
}

void mergeFilter() {
    char img2Name[103];
    cout << "Enter image 2 file name: " << endl;
    string fileName;
    cin >> fileName;
    fileName = "../" + fileName;
    for (int i = 0; i < fileName.length(); ++i)img2Name[i] = fileName[i];
    img2Name[fileName.length()] = '\0';

    // Add .bmp extension and load image1
    strcat(img2Name, ".bmp");
    readGSBMP(img2Name, image2);
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            image1[i][j] = (image1[i][j] + image2[i][j]) / 2;
        }
    }
}

void shrinkImage() {
    int choice;
    cout << "enter 1 to shrink 1/2" << endl << "enter 2 to shrink 1/3" << endl << "enter 3 to shrink 1/4" << endl;
    cout << "enter your choice:";
    cin >> choice;
    while (true) {
        if (choice == 1) {
            int c;
            for (int i = 0; i < SIZE; i++) {
                c = 0;
                for (int j = 0; j < SIZE / 2; j++) {
                    image1[j][i] = (image1[c][i] + image1[c + 1][i]) / 2;
                    c += 2;
                }
            }
            for (int i = 0; i < SIZE / 2; i++) {
                c = 0;
                for (int j = 0; j < SIZE / 2; j++) {
                    image1[i][j] = (image1[i][c] + image1[i][c + 1]) / 2;
                    c += 2;
                }
            }
            for (int i = SIZE / 2; i < SIZE; i++) {
                for (int j = 0; j < SIZE; j++) {
                    image1[i][j] = 255;
                }
            }
            for (int i = 0; i < SIZE / 2; i++) {
                for (int j = SIZE / 2; j < SIZE; j++) {
                    image1[i][j] = 255;
                }
            }
            break;
        } else if (choice == 2) {
            int c;
            for (int i = 0; i < SIZE; i++) {
                c = 0;
                for (int j = 0; j < SIZE / 3; j++) {
                    image1[j][i] = (image1[c][i] + image1[c + 1][i] + image1[c + 2][i]) / 3;
                    c += 3;
                }
            }
            for (int i = 0; i < SIZE / 3; i++) {
                c = 0;
                for (int j = 0; j < SIZE / 3; j++) {
                    image1[i][j] = (image1[i][c] + image1[i][c + 1] + image1[i][c + 2]) / 3;
                    c += 3;
                }
            }
            for (int i = SIZE / 3; i < SIZE; i++) {
                for (int j = 0; j < SIZE; j++) {
                    image1[i][j] = 255;
                }
            }
            for (int i = 0; i < SIZE / 3; i++) {
                for (int j = SIZE / 3; j < SIZE; j++) {
                    image1[i][j] = 255;
                }
            }
            break;
        } else if (choice == 3) {
            int c;
            for (int i = 0; i < SIZE; i++) {
                c = 0;
                for (int j = 0; j < SIZE / 4; j++) {
                    image1[j][i] = (image1[c][i] + image1[c + 1][i] + image1[c + 2][i] + image1[c + 3][i]) / 4;
                    c += 4;
                }
            }
            for (int i = 0; i < SIZE / 4; i++) {
                c = 0;
                for (int j = 0; j < SIZE / 4; j++) {
                    image1[i][j] =
                            (image1[i][c] + image1[i][c + 1] + image1[i][c + 2] + image1[i][c + 3]) / 4;
                    c += 4;
                }
            }
            for (int i = SIZE / 4; i < SIZE; i++) {
                for (int j = 0; j < SIZE; j++) {
                    image1[i][j] = 255;
                }
            }
            for (int i = 0; i < SIZE / 4; i++) {
                for (int j = SIZE / 4; j < SIZE; j++) {
                    image1[i][j] = 255;
                }
            }
            break;
        } else {
            cout << "error,enter vaild input" << endl << "enter 1 to shrink 1/2" << endl << "enter 2 to shrink 1/3"
                 << endl << "enter 3 to shrink 1/4" << endl << "enter your choice: ";
        }
    }
}


void blurImage() {
    for (int i = 1; i < SIZE; i++) {
        for (int j = 1; j < SIZE; j++) {
            double l = ((image1[i - 1][j] +
                         image1[i][j] +
                         image1[i + 1][j] +
                         image1[i - 1][j - 1] +
                         image1[i][j - 1] +
                         image1[i + 1][j - 1] +
                         image1[i - 1][j + 1] +
                         image1[i][j + 1] +
                         image1[i + 1][j + 1]) / 9.0);
            image1[i][j] = l;
        }
    }
}

void skewH() {
    cout << "Enter Skew angle: ";
    double angle;
    cin >> angle;
    unsigned char tmp[SIZE][SIZE];

    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            tmp[i][j] = 255;
        }
    }

    double leave = tan(angle * 3.14 / 180.0) * SIZE;
    double cmprs = SIZE/(SIZE-leave);
    double move = leave / 256;
    double tkn = 0;
    for (int i = 0; i < SIZE; i++) {
        double cur = 0;
        for (int j = leave - tkn; j < SIZE-tkn; j++) {
            int avg = 0;
            int px = 0;
            for (int k = max(0, (int) ceil(cur - cmprs)); k < min(SIZE, (int) ceil(cur + cmprs)); k++, ++px) {
                avg += image1[i][k];
            }
            avg /= max(1, px);
            tmp[i][j] = avg;
            cur += cmprs;
        }
        tkn += move;
    }
    for (int i = 0; i < SIZE; i++)
        for (int j = 0; j < SIZE; j++)
            image1[i][j] = tmp[i][j];
}

void skewV() {
    cout << "Enter Skew angle: ";
    double angle;
    cin >> angle;
    unsigned char tmp[SIZE][SIZE];

    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            tmp[i][j] = 255;
        }
    }

    double leave = tan(angle * 3.14 / 180.0) * SIZE;
    double cmprs = SIZE / (SIZE - leave);
    double move = leave / 256;
    double tkn = 0;
    for (int j = 0; j < SIZE; j++) {
        double cur = 0;
        for (int i = leave - tkn; i < SIZE - tkn; i++) {
            int avg = 0;
            int px = 0;
            for (int k = max(0, (int)ceil(cur - cmprs)); k < min(SIZE, (int)ceil(cur + cmprs)); k++, ++px) {
                avg += image1[k][j];
            }
            avg /= max(1, px);
            tmp[i][j] = avg;
            cur += cmprs;
        }
        tkn += move;
    }
    for (int i = 0; i < SIZE; i++)
        for (int j = 0; j < SIZE; j++)
            image1[i][j] = tmp[i][j];
}

int main() {
    int choice;
    cout << "Ahlan ya user ya habibi" << endl;
    loadImage();
    cout
            << "Choose filter from the following to apply: " << endl;
    bool flag = true;
    while (flag) {
        cout
                << "1- Darken and Lighten Filter" << endl << "2- Merge Filter" << endl << "3- Shrink Image" << endl
                << "4- Blur Image" << endl << "5- Skew Image Horizontally" << endl << "6- Skew Image Verrtically"
                << endl
                << "Enter 0 to exit editing" << endl;
        cin >> choice;
        switch (choice) {
            case 0:
                flag = false;
                saveImage();
                break;
            case 1: {
                darkenAndLightenFilter();
                break;
            }
            case 2: {
                mergeFilter();
                break;
            }
            case 3: {
                shrinkImage();
                break;
            }
            case 4: {
                blurImage();
                break;
            }
            case 5: {
                skewH();
                break;
            }
            case 6: {
                skewV();
                break;
            }
            default:
                cout << "Wrong entry, try again" << endl;
                break;
        }
        if (choice != 0)cout << "What next?" << endl;
    }
}






