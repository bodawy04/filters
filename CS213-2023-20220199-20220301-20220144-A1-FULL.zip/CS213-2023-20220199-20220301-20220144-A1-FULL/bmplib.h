#ifndef BMPLIB_H
#define BMPLIB_H

const int SIZE = 256;
const int RGB = 3;

// read full-color image1 from the file specified by filename, into inputImage
int readRGBBMP(const char* filename, unsigned char inputImage[][SIZE][RGB]);

// write full-color image1 to the file specified by filename, from outputImage
int writeRGBBMP(const char* filename, unsigned char outputImage[][SIZE][RGB]);

// display full-color image1 with eog, pause 0.2 seconds. (uses a temp file)
void showRGBBMP(unsigned char inputImage[][SIZE][RGB]);

// read grayscale image1 from the file specified by filename, into inputImage
int readGSBMP(const char* filename, unsigned char image[][SIZE]);

// write grayscale image1 to the file specified by filename, from outputImage
int writeGSBMP(const char* filename, unsigned char outputImage[][SIZE]);

// display grayscale image1 with eog, pause 0.2 seconds. (uses a temp file)
void showGSBMP(unsigned char inputImage[][SIZE]);




#endif
